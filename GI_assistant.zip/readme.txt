几个简单的函数，可以处理原神七圣召唤卡组分享图片

*没有函数的调用，请自行编写主函数

内容说明：
GI_imgreader.py 	：图像相关的函数写在这里
GI_randomdeck.py	：提供了一个生成随机卡组的函数
GI_deckrule.py 	：提供判断规则的函数
requirements.txt 	：python需要的库
cardlist,characterlist	：七圣召唤的行动牌和角色牌单卡图片，用于识别卡组
cardlist.csv 	：七圣召唤行动牌的信息表（截至4.2）
character.csv 	：七圣召唤角色牌的信息表（截至4.2）
module.png 	：用于生成卡组预览的背景图
sample.py	：展示了主要的使用方法


苏珺亭，2023.11.06